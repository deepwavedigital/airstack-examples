from __future__ import absolute_import
from warnings import warn
warn("pycuda.sparse is deprecated. and will be removed in 2015.x",
        DeprecationWarning, stacklevel=2)
